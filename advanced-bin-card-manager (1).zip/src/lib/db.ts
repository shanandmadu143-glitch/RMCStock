import type { InventoryItem } from './inventory';

export interface FileMeta { id: number; filename: string; timestamp: number; count: number; }
const DB_NAME = 'BinCardHistoryDB';

function openDB(): Promise<IDBDatabase> {
  return new Promise((resolve, reject) => {
    const request = indexedDB.open(DB_NAME, 2);
    request.onupgradeneeded = () => {
      const db = request.result;
      if (!db.objectStoreNames.contains('metadata')) db.createObjectStore('metadata', { keyPath: 'id', autoIncrement: true });
      if (!db.objectStoreNames.contains('datasets')) db.createObjectStore('datasets', { keyPath: 'id' });
    };
    request.onsuccess = () => resolve(request.result);
    request.onerror = () => reject(request.error);
  });
}

export async function getHistory(): Promise<FileMeta[]> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('metadata', 'readonly');
    const request = transaction.objectStore('metadata').getAll();
    request.onsuccess = () => resolve((request.result as FileMeta[]).sort((a, b) => b.timestamp - a.timestamp));
    request.onerror = () => reject(request.error);
    transaction.oncomplete = () => db.close();
  });
}

export async function getDataset(id: number): Promise<InventoryItem[] | null> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction('datasets', 'readonly');
    const request = transaction.objectStore('datasets').get(id);
    request.onsuccess = () => resolve(request.result?.data ?? null);
    request.onerror = () => reject(request.error);
    transaction.oncomplete = () => db.close();
  });
}

export async function saveDataset(filename: string, data: InventoryItem[]): Promise<FileMeta> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(['metadata', 'datasets'], 'readwrite');
    const metadata = transaction.objectStore('metadata');
    const meta: FileMeta = { id: 0, filename, timestamp: Date.now(), count: data.length };
    const request = metadata.add({ filename, timestamp: meta.timestamp, count: data.length });
    request.onsuccess = () => {
      meta.id = request.result as number;
      transaction.objectStore('datasets').add({ id: meta.id, data });
    };
    transaction.oncomplete = () => { db.close(); resolve(meta); };
    transaction.onerror = () => { db.close(); reject(transaction.error); };
  });
}

export async function deleteDataset(id: number): Promise<void> {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const transaction = db.transaction(['metadata', 'datasets'], 'readwrite');
    transaction.objectStore('metadata').delete(id);
    transaction.objectStore('datasets').delete(id);
    transaction.oncomplete = () => { db.close(); resolve(); };
    transaction.onerror = () => { db.close(); reject(transaction.error); };
  });
}