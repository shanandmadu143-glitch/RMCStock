import * as XLSX from 'xlsx';

export type ColumnKey = 'code' | 'name' | 'opening' | 'receipt' | 'issues' | 'returns' | 'closing';
export type ColumnMap = Record<ColumnKey, number>;
export type SheetRow = unknown[];

export interface InventoryItem {
  matCode: string;
  matName: string;
  opening: number;
  receipt: number;
  issues: number;
  returnQty: number;
  closingStock: number;
  balanceSource: 'file' | 'calculated';
}

export interface PreparedSheet {
  sheetName: string;
  rows: SheetRow[];
  headerIndex: number;
  headers: string[];
  mapping: ColumnMap;
}

export const columnLabels: Record<ColumnKey, string> = {
  code: 'Material code', name: 'Item name', opening: 'Opening stock',
  receipt: 'Received', issues: 'Issued', returns: 'Returns', closing: 'Closing stock',
};

export const columnKeys: ColumnKey[] = ['code', 'name', 'opening', 'receipt', 'issues', 'returns', 'closing'];

const patterns: Record<ColumnKey, RegExp[]> = {
  code: [/material\s*(code|no|number|id)/, /item\s*(code|no|number|id)/, /product\s*(code|no|number|id)/, /stock\s*code/, /sku/, /barcode/, /^code$/, /^id$/, /කේතය/],
  name: [/material\s*(name|description)/, /item\s*(name|description)/, /product\s*(name|description)/, /^description$/, /^details$/, /^name$/, /විස්තරය/, /භාණ්ඩ\s*නාමය/, /නම/],
  opening: [/opening\s*(stock|balance|qty|quantity)?/, /beginning\s*(stock|balance)/, /brought\s*forward/, /balance\s*b\s*f/, /^b\s*f$/, /previous\s*(balance|stock)/, /මුල්\s*ශේෂය/, /ආරම්භක/],
  receipt: [/received/, /receipts?/, /stock\s*in/, /qty\s*in/, /quantity\s*in/, /^in$/, /^rec$/, /inward/, /purchases?/, /ලැබීම්/, /ලැබුණු/],
  issues: [/issued/, /issues?/, /stock\s*out/, /qty\s*out/, /quantity\s*out/, /^out$/, /^iss$/, /outward/, /consumption/, /නිකුත්/],
  returns: [/returns?/, /^ret$/, /ආපසු/],
  closing: [/closing\s*(stock|balance|qty|quantity)?/, /ending\s*(stock|balance)/, /current\s*(stock|balance)/, /final\s*(stock|balance)/, /available\s*(stock|balance|qty)/, /stock\s*on\s*hand/, /on\s*hand/, /^balance$/, /^stock\s*balance$/, /^total\s*stock$/, /balance\s*c\s*f/, /අවසාන\s*ශේෂය/, /ඉතිරි\s*තොගය/, /^ශේෂය$/],
};

function text(value: unknown): string { return value == null ? '' : String(value).trim(); }
function normalized(value: unknown): string {
  return text(value).toLowerCase().replace(/[_\-./()]+/g, ' ').replace(/\s+/g, ' ').trim();
}

function guessMapping(headers: string[]): ColumnMap {
  const mapping = Object.fromEntries(columnKeys.map(key => [key, -1])) as ColumnMap;
  const used = new Set<number>();
  // Specific multi-word matches are assigned before generic labels such as "balance".
  const scored: { key: ColumnKey; index: number; score: number }[] = [];
  headers.forEach((header, index) => {
    const value = normalized(header);
    if (!value) return;
    columnKeys.forEach(key => {
      const matched = patterns[key].find(pattern => pattern.test(value));
      if (matched) scored.push({ key, index, score: matched.source.length + (value.length < 28 ? 8 : 0) });
    });
  });
  scored.sort((a, b) => b.score - a.score);
  scored.forEach(({ key, index }) => {
    if (mapping[key] === -1 && !used.has(index)) { mapping[key] = index; used.add(index); }
  });
  return mapping;
}

export function prepareSheet(workbook: XLSX.WorkBook, sheetName: string): PreparedSheet {
  const sheet = workbook.Sheets[sheetName];
  if (!sheet) throw new Error('Selected sheet could not be found.');
  const rows = XLSX.utils.sheet_to_json<SheetRow>(sheet, { header: 1, defval: '', raw: true, blankrows: false });
  if (!rows.length) throw new Error('This sheet is empty.');

  let best = { score: -1, index: 0, combined: false, mapping: guessMapping(rows[0].map(text)) };
  for (let i = 0; i < Math.min(rows.length, 40); i++) {
    for (const combined of [false, true]) {
      if (combined && i + 1 >= rows.length) continue;
      const width = Math.max(rows[i].length, combined ? rows[i + 1].length : 0);
      const headers = Array.from({ length: width }, (_, col) =>
        combined ? `${text(rows[i][col])} ${text(rows[i + 1][col])}`.trim() : text(rows[i][col]));
      const mapping = guessMapping(headers);
      const matches = columnKeys.filter(key => mapping[key] !== -1).length;
      const score = matches * 10 + (mapping.code !== -1 ? 4 : 0) + (mapping.name !== -1 ? 4 : 0) - (combined ? 1 : 0);
      if (score > best.score) best = { score, index: i, combined, mapping };
    }
  }

  const detected = columnKeys.filter(key => best.mapping[key] !== -1).length;
  if (detected < 2) {
    best = { score: 0, index: 0, combined: false, mapping: { code: 0, name: 1, opening: -1, receipt: 2, issues: 3, returns: 4, closing: -1 } };
  }
  const width = Math.max(...rows.slice(0, Math.min(rows.length, 20)).map(row => row.length), 0);
  const headers = Array.from({ length: width }, (_, col) => {
    const label = best.combined ? `${text(rows[best.index][col])} ${text(rows[best.index + 1]?.[col])}`.trim() : text(rows[best.index][col]);
    return label || `Column ${col + 1}`;
  });
  return { sheetName, rows, headerIndex: best.index + (best.combined ? 1 : 0), headers, mapping: best.mapping };
}

export function parseNumber(value: unknown): number | null {
  if (value === '' || value === undefined || value === null) return null;
  if (typeof value === 'number') return Number.isFinite(value) ? value : null;
  let str = String(value).trim();
  const negative = /^\(.*\)$/.test(str);
  if (negative) str = str.slice(1, -1);
  str = str.replace(/,/g, '').replace(/\s/g, '').replace(/^(?:rs\.?|lkr|\$)/i, '');
  if (!/^[+-]?\d*\.?\d+$/.test(str)) return null;
  const number = Number(str);
  return Number.isFinite(number) ? (negative ? -number : number) : null;
}

export function parseInventory(sheet: PreparedSheet, mapping: ColumnMap): InventoryItem[] {
  if (mapping.code === -1 && mapping.name === -1) throw new Error('Select a material code or item name column.');
  if (['opening', 'receipt', 'issues', 'returns', 'closing'].every(key => mapping[key as ColumnKey] === -1)) {
    throw new Error('Select at least one stock quantity column.');
  }
  const items = new Map<string, InventoryItem>();
  let lastIdentity: { code: string; name: string } | null = null;
  for (const row of sheet.rows.slice(sheet.headerIndex + 1)) {
    const get = (key: ColumnKey) => mapping[key] < 0 ? '' : row[mapping[key]];
    let code = text(get('code'));
    let name = text(get('name'));
    if (/^(grand\s*total|sub\s*total|total|එකතුව)/i.test(code) || /^(grand\s*total|sub\s*total|total|එකතුව)/i.test(name)) { lastIdentity = null; continue; }
    if (patterns.code.some(rx => rx.test(normalized(code))) && patterns.name.some(rx => rx.test(normalized(name)))) { lastIdentity = null; continue; }

    const opening = parseNumber(get('opening'));
    const receipt = parseNumber(get('receipt'));
    const issues = parseNumber(get('issues'));
    const returns = parseNumber(get('returns'));
    const closing = parseNumber(get('closing'));
    if ([opening, receipt, issues, returns, closing].every(value => value === null)) continue;
    // Transaction ledgers often merge item cells vertically, leaving later movement rows blank.
    if (!code && !name && lastIdentity) { code = lastIdentity.code; name = lastIdentity.name; }
    if (!code && !name) continue;
    if (code || name) lastIdentity = { code, name };

    const key = (code || name).toLocaleLowerCase();
    let item = items.get(key);
    if (!item) {
      item = { matCode: code || name, matName: name || code, opening: opening ?? 0, receipt: 0, issues: 0, returnQty: 0, closingStock: opening ?? 0, balanceSource: 'calculated' };
      items.set(key, item);
    } else if (!item.matName && name) item.matName = name;

    item.receipt += receipt ?? 0;
    item.issues += issues ?? 0;
    item.returnQty += returns ?? 0;
    // A supplied balance is authoritative. Otherwise carry forward the last balance and movements.
    if (closing !== null) {
      item.closingStock = closing;
      item.balanceSource = 'file';
    } else {
      item.closingStock += (receipt ?? 0) - (issues ?? 0) + (returns ?? 0);
      item.balanceSource = 'calculated';
    }
  }
  return [...items.values()].map(item => ({ ...item, closingStock: Number(item.closingStock.toFixed(6)) }));
}

export async function readWorkbook(file: File): Promise<XLSX.WorkBook> {
  if (!/\.(xlsx|xls|csv)$/i.test(file.name)) throw new Error('Please choose an .xlsx, .xls or .csv file.');
  const buffer = await file.arrayBuffer();
  return XLSX.read(buffer, { type: 'array', cellFormula: true, cellDates: true });
}