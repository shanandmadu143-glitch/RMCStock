import { useEffect, useMemo, useRef, useState } from 'react';
import type { ChangeEvent, DragEvent } from 'react';
import type * as XLSX from 'xlsx';
import { jsPDF } from 'jspdf';
import autoTable from 'jspdf-autotable';
import { ArrowDownLeft, ArrowDownToLine, ArrowRight, ArrowUpRight, Boxes, Check, ChevronDown, ChevronLeft, ChevronRight, Clock3, CloudUpload, FileSpreadsheet, FileText, FolderOpen, History, LayoutDashboard, ListFilter, Menu, Package, Plus, Search, Settings2, ShieldCheck, SlidersHorizontal, Sparkles, Trash2, UploadCloud, Warehouse, X } from 'lucide-react';
import { deleteDataset, getDataset, getHistory, saveDataset } from './lib/db';
import type { FileMeta } from './lib/db';
import { columnKeys, columnLabels, parseInventory, prepareSheet, readWorkbook } from './lib/inventory';
import type { ColumnMap, InventoryItem, PreparedSheet } from './lib/inventory';

type Modal = 'upload' | 'history' | 'settings' | 'delete' | null;
type Theme = 'indigo' | 'emerald' | 'sunset' | 'dark' | 'purple';
type Filter = 'all' | 'low' | 'out';
const PAGE_SIZE = 12;
const themes: { id: Theme; label: string; color: string }[] = [
  { id: 'indigo', label: 'Indigo', color: '#5558db' }, { id: 'emerald', label: 'Emerald', color: '#0b9b75' },
  { id: 'sunset', label: 'Sunset', color: '#e47742' }, { id: 'dark', label: 'Midnight', color: '#273654' },
  { id: 'purple', label: 'Purple', color: '#934bc6' },
];
const demoItems: InventoryItem[] = [
  { matCode: 'MAT-001', matName: 'Stainless Steel Bolts M8', opening: 120, receipt: 80, issues: 54, returnQty: 4, closingStock: 150, balanceSource: 'calculated' },
  { matCode: 'MAT-002', matName: 'Industrial Safety Gloves', opening: 48, receipt: 20, issues: 60, returnQty: 0, closingStock: 8, balanceSource: 'calculated' },
  { matCode: 'MAT-003', matName: 'Hydraulic Oil 5L', opening: 24, receipt: 30, issues: 18, returnQty: 2, closingStock: 38, balanceSource: 'calculated' },
  { matCode: 'MAT-004', matName: 'Copper Wire 2.5mm', opening: 15, receipt: 10, issues: 25, returnQty: 0, closingStock: 0, balanceSource: 'calculated' },
  { matCode: 'MAT-005', matName: 'Air Filter Cartridge', opening: 35, receipt: 15, issues: 12, returnQty: 0, closingStock: 38, balanceSource: 'calculated' },
  { matCode: 'MAT-006', matName: 'PVC Pipe Fittings', opening: 60, receipt: 25, issues: 30, returnQty: 3, closingStock: 58, balanceSource: 'calculated' },
];
function fmt(value: number) { return value.toLocaleString('en-US', { maximumFractionDigits: 2 }); }
function dateFmt(value: number) { return new Date(value).toLocaleString('en-US', { dateStyle: 'medium', timeStyle: 'short' }); }
function status(item: InventoryItem) { return item.closingStock <= 0 ? 'out' : item.closingStock < 10 ? 'low' : 'healthy'; }
function errorMessage(error: unknown) { return error instanceof Error ? error.message : 'Something went wrong. Please try again.'; }

export default function App() {
  const [theme, setTheme] = useState<Theme>(() => (localStorage.getItem('binCardTheme') as Theme) || 'indigo');
  const [modal, setModal] = useState<Modal>(null);
  const [history, setHistory] = useState<FileMeta[]>([]);
  const [active, setActive] = useState<FileMeta | null>(null);
  const [items, setItems] = useState<InventoryItem[]>([]);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<Filter>('all');
  const [page, setPage] = useState(1);
  const [extraStats, setExtraStats] = useState(false);
  const [view, setView] = useState<'table' | 'cards'>('table');
  const [toast, setToast] = useState<{ id: number; message: string; type: 'success' | 'error' | 'info' } | null>(null);
  const [busy, setBusy] = useState(false);
  const [dragging, setDragging] = useState(false);
  const [workbook, setWorkbook] = useState<XLSX.WorkBook | null>(null);
  const [fileName, setFileName] = useState('');
  const [sheet, setSheet] = useState<PreparedSheet | null>(null);
  const [mapping, setMapping] = useState<ColumnMap | null>(null);
  const [previewCount, setPreviewCount] = useState(0);
  const [deleteTarget, setDeleteTarget] = useState<FileMeta | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const fileInput = useRef<HTMLInputElement>(null);
  const inventoryRef = useRef<HTMLElement>(null);
  const notify = (message: string, type: 'success' | 'error' | 'info' = 'success') => setToast({ id: Date.now(), message, type });

  useEffect(() => {
    let mounted = true;
    getHistory().then(async records => {
      if (!mounted) return;
      setHistory(records);
      const stored = Number(localStorage.getItem('activeBinCardFileId'));
      const selected = records.find(record => record.id === stored) || records[0];
      if (selected) { const data = await getDataset(selected.id); if (mounted && data) { setActive(selected); setItems(data); } }
    }).catch(() => { if (mounted) notify('Could not open local storage. Check browser permissions.', 'error'); });
    return () => { mounted = false; };
  }, []);
  useEffect(() => { document.documentElement.dataset.theme = theme; localStorage.setItem('binCardTheme', theme); }, [theme]);
  useEffect(() => { if (!toast) return; const timer = setTimeout(() => setToast(null), 4000); return () => clearTimeout(timer); }, [toast]);
  useEffect(() => { setPage(1); }, [search, filter, active]);
  useEffect(() => { if (!sheet || !mapping) { setPreviewCount(0); return; } try { setPreviewCount(parseInventory(sheet, mapping).length); } catch { setPreviewCount(0); } }, [sheet, mapping]);

  const filtered = useMemo(() => items.filter(item => `${item.matCode} ${item.matName}`.toLowerCase().includes(search.toLowerCase().trim()) && (filter === 'all' || (filter === 'low' ? status(item) === 'low' : status(item) === 'out'))), [items, search, filter]);
  const previewItems = useMemo(() => { if (!sheet || !mapping) return []; try { return parseInventory(sheet, mapping).slice(0, 3); } catch { return []; } }, [sheet, mapping]);
  const visible = filtered.slice(0, page * PAGE_SIZE);
  const totals = useMemo(() => ({ received: items.reduce((sum, item) => sum + item.receipt, 0), issued: items.reduce((sum, item) => sum + item.issues, 0), stock: items.reduce((sum, item) => sum + item.closingStock, 0), low: items.filter(item => status(item) === 'low').length, out: items.filter(item => status(item) === 'out').length }), [items]);

  async function activate(record: FileMeta) {
    try { const data = await getDataset(record.id); if (!data) throw new Error('This saved file could not be found.'); setActive(record); setItems(data); setSearch(''); setFilter('all'); setModal(null); localStorage.setItem('activeBinCardFileId', String(record.id)); notify(`${record.filename} is now open.`); }
    catch (error) { notify(errorMessage(error), 'error'); }
  }
  async function removeFile() {
    if (!deleteTarget) return;
    try {
      await deleteDataset(deleteTarget.id);
      const remaining = history.filter(record => record.id !== deleteTarget.id); setHistory(remaining);
      if (active?.id === deleteTarget.id) {
        const next = remaining[0];
        if (next) { const data = await getDataset(next.id); setActive(next); setItems(data || []); localStorage.setItem('activeBinCardFileId', String(next.id)); }
        else { setActive(null); setItems([]); localStorage.removeItem('activeBinCardFileId'); }
      }
      setDeleteTarget(null); setModal('history'); notify('File removed from this browser.');
    } catch (error) { notify(errorMessage(error), 'error'); }
  }
  async function handleFile(file?: File) {
    if (!file) return; setBusy(true);
    try { const book = await readWorkbook(file); const prepared = prepareSheet(book, book.SheetNames[0]); setWorkbook(book); setFileName(file.name); setSheet(prepared); setMapping(prepared.mapping); setModal('upload'); }
    catch (error) { notify(errorMessage(error), 'error'); }
    finally { setBusy(false); if (fileInput.current) fileInput.current.value = ''; }
  }
  function selectSheet(name: string) { if (!workbook) return; try { const prepared = prepareSheet(workbook, name); setSheet(prepared); setMapping(prepared.mapping); } catch (error) { notify(errorMessage(error), 'error'); } }
  async function importFile() {
    if (!sheet || !mapping) return; setBusy(true);
    try {
      const data = parseInventory(sheet, mapping);
      if (!data.length) throw new Error('No valid inventory rows found. Check your column mapping and sheet.');
      const record = await saveDataset(fileName, data); setHistory(previous => [record, ...previous]); setActive(record); setItems(data); setSearch(''); setFilter('all');
      localStorage.setItem('activeBinCardFileId', String(record.id)); setModal(null); setWorkbook(null); setSheet(null); setMapping(null);
      notify(`${data.length} items imported. Closing balances are ready.`);
    } catch (error) { notify(errorMessage(error), 'error'); }
    finally { setBusy(false); }
  }
  async function loadDemo() {
    try { const record = await saveDataset('Sample inventory', demoItems); setHistory(previous => [record, ...previous]); setActive(record); setItems(demoItems); localStorage.setItem('activeBinCardFileId', String(record.id)); notify('Sample inventory loaded. You can replace it with your own file.'); }
    catch (error) { notify(errorMessage(error), 'error'); }
  }
  function exportPdf() {
    if (!filtered.length) { notify('There are no items to export.', 'info'); return; }
    try {
      const doc = new jsPDF({ unit: 'pt', format: 'a4' }); doc.setFont('helvetica', 'bold'); doc.setFontSize(17); doc.setTextColor(35, 45, 75); doc.text('Inventory Bin Card Report', 40, 42);
      doc.setFont('helvetica', 'normal'); doc.setFontSize(9); doc.setTextColor(112, 122, 141);
      const safeFile = (active?.filename || 'Inventory').replace(/[^\x20-\x7E]/g, '?');
      doc.text(`File: ${safeFile}   |   ${new Date().toLocaleString()}   |   ${filtered.length} items`, 40, 60);
      autoTable(doc, { startY: 78, head: [['Code', 'Item name', 'Opening', 'In', 'Out', 'Returns', 'Closing']], body: filtered.map(item => [item.matCode, item.matName, fmt(item.opening), fmt(item.receipt), fmt(item.issues), fmt(item.returnQty), fmt(item.closingStock)]), theme: 'grid', styles: { fontSize: 8, cellPadding: 6, overflow: 'linebreak' }, headStyles: { fillColor: [82, 86, 211], textColor: 255 }, columnStyles: { 2: { halign: 'right' }, 3: { halign: 'right' }, 4: { halign: 'right' }, 5: { halign: 'right' }, 6: { halign: 'right', fontStyle: 'bold' } }, margin: { left: 35, right: 35 } });
      doc.save(`BinCard_${(active?.filename || 'inventory').replace(/\.[^.]+$/, '')}.pdf`); notify('PDF report downloaded.');
    } catch (error) { notify(errorMessage(error), 'error'); }
  }
  function onDrop(event: DragEvent<HTMLDivElement>) { event.preventDefault(); setDragging(false); handleFile(event.dataTransfer.files[0]); }
  function onInput(event: ChangeEvent<HTMLInputElement>) { handleFile(event.target.files?.[0]); }
  const openUpload = () => { setWorkbook(null); setSheet(null); setMapping(null); setModal('upload'); setSidebarOpen(false); };

  return <div className="app-shell">
    {sidebarOpen && <button className="mobile-scrim" onClick={() => setSidebarOpen(false)} aria-label="Close navigation" />}
    <aside className={`sidebar ${sidebarOpen ? 'sidebar-open' : ''}`}>
      <div className="brand"><span className="brand-mark"><Boxes size={23} strokeWidth={2.2} /></span><span className="brand-copy"><strong>bin<span>card.</span></strong><small>INVENTORY MANAGER</small></span></div>
      <div className="side-caption">WORKSPACE</div>
      <nav className="side-nav" aria-label="Main navigation">
        <button className="nav-link active" onClick={() => { window.scrollTo({ top: 0, behavior: 'smooth' }); setSidebarOpen(false); }}><LayoutDashboard size={18} /> Overview <span className="nav-active-dot" /></button>
        <button className="nav-link" onClick={() => { inventoryRef.current?.scrollIntoView({ behavior: 'smooth' }); setSidebarOpen(false); }}><Package size={18} /> Inventory</button>
        <button className="nav-link" onClick={() => { setModal('history'); setSidebarOpen(false); }}><History size={18} /> File history {history.length > 0 && <span className="nav-count">{history.length}</span>}</button>
      </nav>
      <div className="side-caption side-caption-tools">PREFERENCES</div><nav className="side-nav"><button className="nav-link" onClick={() => { setModal('settings'); setSidebarOpen(false); }}><Settings2 size={18} /> Appearance</button></nav>
      <div className="sidebar-bottom"><div className="sidebar-tip"><div className="tip-symbol"><Sparkles size={16} /></div><strong>Smarter stock tracking</strong><p>Balances from your file, or calculated automatically when missing.</p><button onClick={openUpload}>Import a file <ArrowRight size={14} /></button></div><div className="sidebar-credit">Created by <strong>Yomal Lakshan</strong></div></div>
    </aside>

    <main className="main-area"><header className="topbar"><div className="topbar-left"><button className="mobile-menu icon-button" onClick={() => setSidebarOpen(true)} aria-label="Open menu"><Menu size={21} /></button><span className="breadcrumb">Workspace</span><ChevronRight size={15} className="breadcrumb-chevron" /><span className="breadcrumb-current">Overview</span></div><div className="topbar-actions"><span className="topbar-date"><Clock3 size={15} /> {new Date().toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}</span><div className="topbar-divider" /><button className="topbar-avatar" onClick={() => setModal('settings')} title="Settings">YL</button></div></header>
      <div className="content">
        <section className="page-intro"><div><div className="eyebrow"><span className="eyebrow-line" /> YOUR INVENTORY, AT A GLANCE</div><h1>Inventory overview<span className="heading-period">.</span></h1><p>Keep every item accounted for, from first receipt to final balance.</p></div><div className="intro-actions"><button className="button button-quiet" onClick={exportPdf} disabled={!active}><ArrowDownToLine size={17} /> Export PDF</button><button className="button button-primary" onClick={openUpload}><Plus size={18} /> Upload Excel</button></div></section>
        <div className="file-context"><div className="file-context-left"><span className="context-icon"><FileSpreadsheet size={17} /></span><div><strong>{active ? active.filename : 'No file selected'}</strong><span>{active ? `Last opened from local storage · ${fmt(items.length)} items` : 'Upload a spreadsheet to get started'}</span></div></div><button onClick={() => setModal('history')}>Switch file <ChevronDown size={15} /></button></div>
        <section className="overview-section" aria-label="Inventory summary"><div className="section-heading"><div><h2>At a glance</h2><p>A quick look at your current inventory.</p></div><button className="text-action" onClick={() => setExtraStats(!extraStats)}><SlidersHorizontal size={16} /> {extraStats ? 'Hide details' : 'More details'}</button></div>
          <div className="stats-grid">
            <div className="stat-block"><div className="stat-top"><span className="stat-label">TOTAL ITEMS</span><span className="stat-icon stat-icon-indigo"><Boxes size={19} /></span></div><strong>{fmt(items.length)}</strong><span className="stat-foot">Products in this file</span><div className="stat-accent accent-indigo" /></div>
            <div className="stat-block"><div className="stat-top"><span className="stat-label">TOTAL RECEIVED</span><span className="stat-icon stat-icon-green"><ArrowDownLeft size={19} /></span></div><strong>{fmt(totals.received)}</strong><span className="stat-foot">Units brought in</span><div className="stat-accent accent-green" /></div>
            <div className="stat-block"><div className="stat-top"><span className="stat-label">TOTAL ISSUED</span><span className="stat-icon stat-icon-orange"><ArrowUpRight size={19} /></span></div><strong>{fmt(totals.issued)}</strong><span className="stat-foot">Units sent out</span><div className="stat-accent accent-orange" /></div>
            <div className="stat-block"><div className="stat-top"><span className="stat-label">CLOSING STOCK</span><span className="stat-icon stat-icon-violet"><Warehouse size={19} /></span></div><strong>{fmt(totals.stock)}</strong><span className="stat-foot">Units currently on hand</span><div className="stat-accent accent-violet" /></div>
          </div>{extraStats && <div className="details-line"><span><span className="tiny-dot dot-amber" /> Low stock <strong>{totals.low}</strong></span><span><span className="tiny-dot dot-red" /> Out of stock <strong>{totals.out}</strong></span><span><ShieldCheck size={16} /> Balances prioritize the closing stock column in your file</span></div>}
        </section>
        <section className="inventory-section" ref={inventoryRef}><div className="section-heading inventory-heading"><div><h2>Inventory items <span className="section-count">{fmt(filtered.length)}</span></h2><p>Search and explore the details behind every balance.</p></div><div className="view-switch" aria-label="Display view"><button className={view === 'table' ? 'selected' : ''} onClick={() => setView('table')}>List</button><button className={view === 'cards' ? 'selected' : ''} onClick={() => setView('cards')}>Cards</button></div></div>
          <div className="inventory-panel"><div className="inventory-toolbar"><div className="search-field"><Search size={18} /><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Search code or item name..." disabled={!active} /></div><div className="toolbar-right"><ListFilter size={17} className="filter-icon" /><select value={filter} onChange={event => setFilter(event.target.value as Filter)} disabled={!active} aria-label="Filter stock status"><option value="all">All stock</option><option value="low">Low stock</option><option value="out">Out of stock</option></select><ChevronDown size={15} className="select-arrow" /></div></div>
            {!active ? <div className="empty-state"><div className="empty-art"><div className="empty-art-glow" /><span className="empty-art-back"><FileText size={49} strokeWidth={1.4} /></span><span className="empty-art-front"><Package size={38} strokeWidth={1.6} /></span><span className="empty-art-spark one" /><span className="empty-art-spark two" /></div><h3>Your inventory starts here</h3><p>Upload an Excel or CSV file to see your items, track movement, and get accurate closing stock instantly.</p><div className="empty-actions"><button className="button button-primary" onClick={openUpload}><UploadCloud size={17} /> Upload your first file</button><button className="button button-link" onClick={loadDemo}>Explore sample data <ArrowRight size={16} /></button></div><span className="empty-hint">Files are saved privately in your browser using IndexedDB.</span></div>
              : filtered.length === 0 ? <div className="no-results"><Search size={30} /><h3>No matching items</h3><p>Try another search or stock filter.</p><button onClick={() => { setSearch(''); setFilter('all'); }}>Clear filters</button></div>
              : view === 'table' ? <div className="table-scroll"><table className="inventory-table"><thead><tr><th>ITEM / MATERIAL</th><th>OPENING</th><th>RECEIVED</th><th>ISSUED</th><th>RETURNS</th><th>CLOSING STOCK</th><th>STATUS</th></tr></thead><tbody>{visible.map((item, index) => <tr key={`${item.matCode}-${index}`}><td><div className="item-cell"><span className="item-symbol"><Package size={18} /></span><span><strong>{item.matName}</strong><small>{item.matCode}</small></span></div></td><td>{fmt(item.opening)}</td><td className="number-green">+{fmt(item.receipt)}</td><td className="number-orange">-{fmt(item.issues)}</td><td>{fmt(item.returnQty)}</td><td><div className="closing-cell"><strong>{fmt(item.closingStock)}</strong><span title={item.balanceSource === 'file' ? 'Read from file closing stock column' : 'Calculated from opening and movements'}>{item.balanceSource === 'file' ? 'From file' : 'Calculated'}</span></div></td><td><StatusBadge value={status(item)} /></td></tr>)}</tbody></table></div>
              : <div className="item-cards">{visible.map((item, index) => <div className="item-card" key={`${item.matCode}-${index}`}><div className="item-card-top"><div><small>{item.matCode}</small><h3>{item.matName}</h3></div><StatusBadge value={status(item)} /></div><div className="item-card-data"><span>Opening <strong>{fmt(item.opening)}</strong></span><span>Received <strong className="number-green">+{fmt(item.receipt)}</strong></span><span>Issued <strong className="number-orange">-{fmt(item.issues)}</strong></span><span>Returns <strong>{fmt(item.returnQty)}</strong></span></div><div className="item-card-bottom"><span>Closing stock <small>{item.balanceSource === 'file' ? 'From file' : 'Calculated'}</small></span><strong>{fmt(item.closingStock)}</strong></div></div>)}</div>}
            {active && filtered.length > 0 && <div className="table-footer"><span>Showing <strong>{visible.length}</strong> of <strong>{filtered.length}</strong> items</span><div className="pagination"><button disabled={page === 1} onClick={() => setPage(page - 1)} aria-label="Previous page"><ChevronLeft size={17} /></button><span>Page {page} of {Math.ceil(filtered.length / PAGE_SIZE)}</span><button disabled={visible.length >= filtered.length} onClick={() => setPage(page + 1)} aria-label="Next page"><ChevronRight size={17} /></button></div></div>}
          </div>
        </section><footer className="footer"><span>Bin Card Manager <span className="footer-dot">·</span> Made by Yomal Lakshan</span><span>Stored locally in your browser <ShieldCheck size={15} /></span></footer>
      </div>
    </main>
    {toast && <div className={`toast toast-${toast.type}`} role="status"><span>{toast.type === 'success' ? <Check size={18} /> : toast.type === 'error' ? <X size={18} /> : <Sparkles size={18} />}</span>{toast.message}<button onClick={() => setToast(null)} aria-label="Dismiss"><X size={15} /></button></div>}
    {modal && <div className="modal-overlay" onMouseDown={event => { if (event.target === event.currentTarget) setModal(null); }}>
      {modal === 'upload' && <div className="modal upload-modal" role="dialog" aria-modal="true" aria-label="Upload inventory"><div className="modal-header"><div className="modal-icon"><CloudUpload size={23} /></div><button className="modal-close" onClick={() => setModal(null)} aria-label="Close"><X size={20} /></button></div><h2>Upload inventory file</h2><p className="modal-subtitle">Import your spreadsheet and review the detected columns before saving.</p>
        {!sheet ? <><div className={`dropzone ${dragging ? 'dragging' : ''}`} onDragOver={event => { event.preventDefault(); setDragging(true); }} onDragLeave={() => setDragging(false)} onDrop={onDrop} onClick={() => fileInput.current?.click()} role="button" tabIndex={0} onKeyDown={event => { if (event.key === 'Enter') fileInput.current?.click(); }}><div className="dropzone-icon"><UploadCloud size={27} /></div><strong>{busy ? 'Reading file...' : 'Drop your file here, or browse'}</strong><span>Supports XLSX, XLS and CSV files</span><button className="button button-primary" type="button" onClick={event => { event.stopPropagation(); fileInput.current?.click(); }}>Choose file</button></div><div className="upload-note"><ShieldCheck size={17} /><span>Your file never leaves this device. Data is stored in IndexedDB.</span></div></> : <><div className="selected-file"><FileSpreadsheet size={22} /><div><strong>{fileName}</strong><span>{workbook?.SheetNames.length || 1} sheet(s) found</span></div><button onClick={() => { setSheet(null); setWorkbook(null); setMapping(null); }} title="Choose another file"><X size={18} /></button></div>
          {workbook && workbook.SheetNames.length > 1 && <label className="form-field">Worksheet<select value={sheet.sheetName} onChange={event => selectSheet(event.target.value)}>{workbook.SheetNames.map(name => <option key={name} value={name}>{name}</option>)}</select></label>}
          <div className="mapping-title"><div><h3>Check column mapping</h3><p>We matched these columns automatically. Adjust any that look wrong.</p></div><span className="detected-pill"><Check size={13} /> {previewCount} items found</span></div>
          <div className="mapping-grid">{columnKeys.map(key => <label className="form-field" key={key}>{columnLabels[key]}{key === 'closing' && <span className="field-hint">preferred</span>}<select value={mapping?.[key] ?? -1} onChange={event => setMapping(previous => previous ? { ...previous, [key]: Number(event.target.value) } : null)}><option value={-1}>Not in file</option>{sheet.headers.map((header, index) => <option key={index} value={index}>{header} ({String.fromCharCode(65 + index)})</option>)}</select></label>)}</div>
          {previewItems.length > 0 && <div className="import-preview"><div className="import-preview-title">BALANCE PREVIEW <span>First {previewItems.length} items</span></div>{previewItems.map((item, index) => <div className="import-preview-row" key={`${item.matCode}-${index}`}><span><strong>{item.matName}</strong><small>{item.matCode}</small></span><span><strong>{fmt(item.closingStock)}</strong><small>{item.balanceSource === 'file' ? 'From file' : 'Calculated'}</small></span></div>)}</div>}
          <div className="preview-box"><strong>Balance logic</strong><p>{mapping?.closing !== -1 ? 'The closing stock value in your file is used first. If a row is blank, its balance is calculated from opening stock + received - issued + returns.' : 'No closing stock column selected. Balances will be calculated as opening stock + received - issued + returns.'}</p></div>
          <div className="modal-actions"><button className="button button-quiet" onClick={() => setModal(null)}>Cancel</button><button className="button button-primary" disabled={busy || !previewCount} onClick={importFile}>{busy ? 'Importing...' : `Import ${previewCount} items`} <ArrowRight size={16} /></button></div></>}
        <input ref={fileInput} type="file" accept=".xlsx,.xls,.csv" hidden onChange={onInput} />
      </div>}
      {modal === 'history' && <div className="modal history-modal" role="dialog" aria-modal="true" aria-label="File history"><div className="modal-header"><div className="modal-icon"><History size={22} /></div><button className="modal-close" onClick={() => setModal(null)} aria-label="Close"><X size={20} /></button></div><h2>File history</h2><p className="modal-subtitle">Your previously imported files, saved on this device.</p>{history.length ? <div className="history-list">{history.map(record => <div className={`history-row ${active?.id === record.id ? 'history-active' : ''}`} key={record.id}><span className="history-file-icon"><FileSpreadsheet size={20} /></span><div className="history-text"><strong>{record.filename}</strong><span>{dateFmt(record.timestamp)} · {fmt(record.count || 0)} items</span></div><div className="history-controls">{active?.id === record.id ? <span className="current-tag">Current</span> : <button className="history-open" onClick={() => activate(record)}>Open</button>}<button className="history-delete" onClick={() => { setDeleteTarget(record); setModal('delete'); }} title="Delete file"><Trash2 size={17} /></button></div></div>)}</div> : <div className="history-empty"><FolderOpen size={36} /><strong>No saved files yet</strong><span>Imported spreadsheets will appear here.</span></div>}<button className="button button-primary history-upload" onClick={openUpload}><Plus size={17} /> Upload another file</button></div>}
      {modal === 'settings' && <div className="modal settings-modal" role="dialog" aria-modal="true" aria-label="Appearance settings"><div className="modal-header"><div className="modal-icon"><Settings2 size={22} /></div><button className="modal-close" onClick={() => setModal(null)} aria-label="Close"><X size={20} /></button></div><h2>Appearance</h2><p className="modal-subtitle">Make your workspace feel like yours.</p><div className="settings-label">COLOR THEME</div><div className="theme-list">{themes.map(option => <button key={option.id} className={`theme-option ${theme === option.id ? 'theme-selected' : ''}`} onClick={() => setTheme(option.id)}><span className="theme-swatch" style={{ background: option.color }} />{option.label}{theme === option.id && <Check size={17} />}</button>)}</div><div className="settings-note"><ShieldCheck size={18} /><span>Theme preference and uploaded files are saved in this browser.</span></div></div>}
      {modal === 'delete' && <div className="modal delete-modal" role="alertdialog" aria-modal="true" aria-label="Confirm delete"><div className="delete-icon"><Trash2 size={24} /></div><h2>Delete this file?</h2><p className="modal-subtitle"><strong>{deleteTarget?.filename}</strong> and its saved inventory data will be permanently removed from this browser.</p><div className="modal-actions"><button className="button button-quiet" onClick={() => { setModal('history'); setDeleteTarget(null); }}>Cancel</button><button className="button button-danger" onClick={removeFile}>Delete file</button></div></div>}
    </div>}
  </div>;
}
function StatusBadge({ value }: { value: 'healthy' | 'low' | 'out' }) { return <span className={`status-badge status-${value}`}><span />{value === 'healthy' ? 'In stock' : value === 'low' ? 'Low stock' : 'Out of stock'}</span>; }